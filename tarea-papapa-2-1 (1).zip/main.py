# Sumar los elementos de una lista
numeros = [1, 2, 3, 4, 5]
suma = sum(numeros)

print("Suma de los elementos de la lista:", suma)  


import math
tupla_numeros = (1, 2, 3, 4, 5)
producto = math.prod(tupla_numeros)

print("Producto de los elementos de la tupla:", producto) 

