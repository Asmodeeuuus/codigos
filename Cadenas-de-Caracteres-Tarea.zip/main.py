def procesar_texto(texto):
  
  texto_mayusculas = texto.upper()

  
  texto_minusculas = texto.lower()


  dos_primeros = texto[:2]

  
  dos_ultimos = texto[-2:]

 
  ultimo_caracter = texto[-1]
  repeticiones_ultimo = texto.count(ultimo_caracter)

  
  texto_invertido = texto[::-1]

  return (texto_mayusculas, texto_minusculas, dos_primeros, dos_ultimos, repeticiones_ultimo, texto_invertido)


texto = "Mi nombre es Ivan Ricardo, tengo 19 años y soy mitad cololmbiano, puertorriqueño, argentino y sobretodo y mas importante DOMINICANO"
resultados = procesar_texto(texto)


print(f"Texto en mayúsculas: {resultados[0]}")
print(f"Texto en minúsculas: {resultados[1]}")
print(f"Dos primeros caracteres: {resultados[2]}")
print(f"Dos últimos caracteres: {resultados[3]}")
print(f"Repeticiones del último carácter: {resultados[4]}")
print(f"Texto invertido: {resultados[5]}")
