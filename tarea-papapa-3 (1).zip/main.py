 
diccionario = {'nombre': 'Juan', 'edad': 30, 'ciudad': 'Madrid'}

edad = diccionario['edad']
print("Edad:", edad)  


diccionario['ciudad'] = 'Barcelona'
print("Diccionario modificado:", diccionario)  
